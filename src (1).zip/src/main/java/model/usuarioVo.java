package model;

public class usuarioVo{

    
    
    
    
    private  String conntrausu; 
 private   String nomusu; 
    private  int  numcelusu ;
private int  usuario    ; 
    private  int  numdoc    ;
  private boolean estadusu;
    public usuarioVo() {
    }  
    
    public usuarioVo(int usuario, int numdoc, String nomusu, String conntrausu, int numcelusu, boolean estadusu) {
        this.usuario = usuario;
        this.numdoc = numdoc;
        this.nomusu = nomusu;
        this.conntrausu = conntrausu;
        this.numcelusu = numcelusu;
        this.estadusu = estadusu;
    }
    public int getUsuario() {
        return usuario;
    }
    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }
    public int getNumdoc() {
        return numdoc;
    }
    public void setNumdoc(int numdoc) {
        this.numdoc = numdoc;
    }
    public String getNomusu() {
        return nomusu;
    }
    public void setNomusu(String nomusu) {
        this.nomusu = nomusu;
    }
    public String getConntrausu() {
        return conntrausu;
    }
    public void setConntrausu(String conntrausu) {
        this.conntrausu = conntrausu;
    }
    public int getNumcelusu() {
        return numcelusu;
    }
    public void setNumcelusu(int numcelusu) {
        this.numcelusu = numcelusu;
    }
    public boolean isEstadusu() {
        return estadusu;
    }
    public void setEstadusu(boolean estadusu) {
        this.estadusu = estadusu;
    }
   


}
