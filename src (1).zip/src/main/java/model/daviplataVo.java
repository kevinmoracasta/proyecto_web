package model;

public class daviplataVo { 
private int cuenta; 
private int usuario;
private int Saldo; 
private Boolean EstadoActivo; 
public daviplataVo() {
}

public daviplataVo(int cuenta, int usuario, int saldo, Boolean estadoActivo) {
    this.cuenta = cuenta;
    this.usuario = usuario;
    Saldo = saldo;
    EstadoActivo = estadoActivo;
}

public int getCuenta() {
    return cuenta;
}

public void setCuenta(int cuenta) {
    this.cuenta = cuenta;
}

public int getUsuario() {
    return usuario;
}

public void setUsuario(int usuario) {
    this.usuario = usuario;
}

public int getSaldo() {
    return Saldo;
}

public void setSaldo(int saldo) {
    Saldo = saldo;
}

public Boolean getEstadoActivo() {
    return EstadoActivo;
}

public void setEstadoActivo(Boolean estadoActivo) {
    EstadoActivo = estadoActivo;
}


}
