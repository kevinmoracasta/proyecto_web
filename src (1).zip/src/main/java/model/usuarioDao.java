package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class usuarioDao {
    

    Connection con; 
    PreparedStatement ps; 
    ResultSet rs; 
    String sql=null;
    int retor; 

    public int registrar(usuarioVo usuario) throws SQLException{
        sql="INSERT INTO usuario(N_documento,Nombreusuario,ConstrasenaUsuario,NumeroCelularUsuario,EstadoUsuario) values(?,?,?,?,?)";
        try{
            con=conexion.conectar(); 
            ps=con.prepareStatement(sql); 
            ps.setInt(1, usuario.getNumdoc());
            ps.setString(2, usuario.getNomusu());
            ps.setString(3, usuario.getConntrausu());
            ps.setInt(4, usuario.getNumcelusu());
            ps.setBoolean(5, usuario.isEstadusu());;
            System.out.println(ps);
            ps.executeUpdate(); 
            ps.close(); 
        }catch(Exception e){
            System.out.println("Error en el regisro "+e.getMessage().toString());
        }
        finally{
            con.close();
        }
        return retor;
    }

    public List<usuarioVo> listar() throws SQLException{
        sql="SELECT *from usuario";
        List<usuarioVo> usuario=new ArrayList<>();
        try {
            con=conexion.conectar();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery(sql);
            while(rs.next()){
                 usuarioVo retor =new usuarioVo();  
                 
                    retor.setUsuario(rs.getInt("IdUsuario")); 
                    
                    retor.setNumdoc(rs.getInt("N_documento"));
                
                    retor.setNomusu(rs.getString("NombreUsuario"));
                
                    retor.setConntrausu(rs.getString("ConstrasenaUsuario")); 
                 
                    retor.setNumcelusu(rs.getInt("NumeroCelularUsuario")); 
           
                    retor.setEstadusu(rs.getBoolean("EstadoUsuario")); 
                     usuario.add(retor);
            
            } 
             
            ps.close();
        } catch (Exception e) {
            System.out.println("La consulta no pudo ser ejecutado "+e.getMessage().toString());
        }
        finally{
            con.close();
        }

        return usuario;
    }   


public int actualizar(usuarioVo usuario) throws SQLException{
      sql="update usuario  set N_documento="+usuario.getNumdoc()+", NombreUsuario='"+usuario.getNomusu()+"',ConstrasenaUsuario='"+usuario.getConntrausu()+"', NumeroCelularUsuario="+usuario.getNumcelusu()+",EstadoUsuario="+usuario.isEstadusu()+" where  IdUsuario="+usuario.getUsuario()+";";
        try{
          con=conexion.conectar(); 
            ps=con.prepareStatement(sql); 
         
            System.out.println(ps);
            ps.executeUpdate(); 
            ps.close();  
        }catch(Exception e){ 

        }
        finally{
            con.close();
        }
        return retor;
    }
}

