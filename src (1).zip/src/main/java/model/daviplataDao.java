package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class daviplataDao { 
    Connection con; 
    PreparedStatement ps; 
    ResultSet rs; 
    String sql=null;
    int retor; 


public int registrar(daviplataVo davi) throws SQLException{
    sql="INSERT INTO daviplata(IdUsuario,Saldo,EstadoActivo) values(?,?,?)";
    try{
        con=conexion.conectar(); //abrir conexión
        ps=con.prepareStatement(sql); //preparar sentencia
        ps.setInt(1, davi.getUsuario());
        ps.setInt(2, davi.getSaldo());
        ps.setBoolean(3,davi.getEstadoActivo());
        System.out.println(ps);
        ps.executeUpdate(); //Ejecutar sentencia
        ps.close(); //cerrar sentencia
    }catch(Exception e){
    }
    finally{
        con.close();//cerrando conexión
    }
    return retor ;
}



    

    public List<daviplataVo> listarC() throws SQLException{ 
        List<daviplataVo> cuentas = new ArrayList<>();
        sql="select * from daviplata "; 
        try {
            con=conexion.conectar();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery(sql);
            while(rs.next()){
            daviplataVo  davi=new daviplataVo();
                davi.setCuenta(rs.getInt("IdCuenta"));
                davi.setUsuario(rs.getInt("IdUsuario"));
                davi.setSaldo(rs.getInt("saldo"));
                davi.setEstadoActivo(rs.getBoolean("EstadoActivo"));
                cuentas.add(davi);
            }
            ps.close();
        } catch (Exception e) {
        }
        finally{
            con.close();
        }
        return cuentas;
    } 
    public int actualizar(daviplataVo davi) throws SQLException{
       sql="update daviplata  set  IdUsuario="+davi.getUsuario()+",Saldo="+davi.getSaldo()+", EstadoActivo="+davi.getEstadoActivo()+" where  IdUCuenta="+davi.getCuenta()+";";
         try{
           con=conexion.conectar(); 
             ps=con.prepareStatement(sql); 
             System.out.println(ps);
             ps.executeUpdate(); 
             ps.close(); 
         }catch(Exception e){ 
 
         }
         finally{
             con.close();
         }
         return retor;
     }
}
