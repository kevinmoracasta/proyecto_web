package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import java.util.List;
import model.usuarioDao;
import model.usuarioVo;

 public class usuario  extends HttpServlet{ 

    usuarioVo s=new usuarioVo();
    usuarioDao s2=new usuarioDao();


    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 

        System.out.println("Entró al Doget");
        String accion=req.getParameter("accion");
         switch (accion){

        case "index":
        //redirecciona con el req
        req.getRequestDispatcher("index.jsp").forward(req, resp);
        break;  
        
        case "login":
        //redirecciona con el req
        req.getRequestDispatcher("login.jsp").forward(req, resp);
        break;
        case "login2":
        //redirecciona con el req
        req.getRequestDispatcher("login2.jsp").forward(req, resp);
        break;
 case "registrar":
        //redirecciona con el req
        req.getRequestDispatcher("registrar.jsp").forward(req, resp);
        break;
        case "registrar2":
        //redirecciona con el req
        req.getRequestDispatcher("registrar2.jsp").forward(req, resp);
        break;
        /* case "dashboard":
        //redirecciona con el req
        req.getRequestDispatcher("dashboard.jsp").forward(req, resp);
        break; */

        case "dashboard2":
        //redirecciona con el req
        req.getRequestDispatcher("dashboard2.jsp").forward(req, resp);
        break;
        case "consultar_saldo2":
        //redirecciona con el req
        req.getRequestDispatcher("consultar_saldo2.jsp").forward(req, resp);
        break;
        case "recarga":
        //redirecciona con el req
        req.getRequestDispatcher("recarga.jsp").forward(req, resp);
        break;
        case "recarga2":
        //redirecciona con el req
        req.getRequestDispatcher("recarga2.jsp").forward(req, resp);
        break;
        case "retirar":
        //redirecciona con el req
        req.getRequestDispatcher("retirar.jsp").forward(req, resp);
        break;
        case "retirar2":
        //redirecciona con el req
        req.getRequestDispatcher("retirar2.jsp").forward(req, resp);
        break;
        case "login - copia":
        //redirecciona con el req
        req.getRequestDispatcher("login - copia.jsp").forward(req, resp);
        break;
        case "login_retirar":
        //redirecciona con el req
        req.getRequestDispatcher("login_retirar.jsp").forward(req, resp);
        break;
        case "login_consulta":
        //redirecciona con el req
        req.getRequestDispatcher("login_consulta.jsp").forward(req, resp);
        break;
         
        case"listar":
        listar(req, resp);
        break;
         
        case"formulario":
        System.out.println("formulario");
        req.getRequestDispatcher("usu_add.jsp").forward(req, resp) ;
        break; 

        case"modificar": 
        System.out.println("modificar");
        actualizar(req, resp); 


        case"usuario":
        System.out.println("formulario");
        req.getRequestDispatcher("usuario.jsp").forward(req, resp) ;
        break; 
        
        case"usu_add":
        System.out.println("formulario");
        req.getRequestDispatcher("usu_add.jsp").forward(req, resp) ;
        break; 

        case"editusu":
        System.out.println("formulario");
        req.getRequestDispatcher("editusu.jsp").forward(req, resp) ;
        break; 
         }

    } 



    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    
        System.out.println("Entró al DoPost");
        String accion=req.getParameter("accion");

        switch ( accion) {
    
    case "enviar": 
            req.getRequestDispatcher("dashboard.jsp").forward(req, resp);
            break;
          case "dashboard": 
              req.getRequestDispatcher("dashboard.jsp").forward(req, resp);
            break;
            case "dashboard2": 
                req.getRequestDispatcher("dashboard2.jsp").forward(req, resp);
              break;
    
            case"registrar": 
          System.out.println("registrar");
            add(req, resp);
            listar(req, resp);


       case "confirmar":
       System.out.println("actualizar post ");
       confirmar(req, resp);
       
       break;


    }
} 
private void add(HttpServletRequest req, HttpServletResponse resp) { 
        
        System.out.println("registrando");

        if(req.getParameter("N_documento")!=null){
            s.setNumdoc( Integer.parseInt(req.getParameter("N_documento")));
        }
        if(req.getParameter("NombreUsuario")!=null){
            s.setNomusu(req.getParameter("NombreUsuario"));
        }
        if(req.getParameter("ContrasenaUsuario")!=null){
            s.setConntrausu(req.getParameter("ContrasenaUsuario"));
        }
        if(req.getParameter("NumeroCelularUsuario")!=null){
            s.setNumcelusu( Integer.parseInt(req.getParameter("NumeroCelularUsuario")));
        } 

        if(req.getParameter("chkestado")!=null){
            s.setEstadusu(true);
        }
        else{
            s.setEstadusu(false);
        }
        try {
            s2.registrar(s);
            System.out.println("Registro insertado correctamente"); 
             listar(req, resp);
         
            
        } catch (Exception e) {
            System.out.println("Error en la inserción del registro "+e.getMessage().toString());
        }
    
      }

 
      private void actualizar(HttpServletRequest req, HttpServletResponse resp) {
        try {
            List usuario = s2.listar();
            req.setAttribute("usuarios",usuario);
            req.getRequestDispatcher("editusu.jsp").forward(req, resp); 
            System.out.println(usuario);
            System.out.println("Datos listados correctamente");
        } catch (Exception e) {
            System.out.println("Hay problemas al listar los datos "+e.getMessage().toString());
        }
    }

    
    private void confirmar(HttpServletRequest req, HttpServletResponse resp) { 
        System.out.println("confirmar bolsillo");
        if(req.getParameter("IdUsuario")!=null){ 
            s.setUsuario(Integer.parseInt(req.getParameter("IdUsuario")));
        }
        if(req.getParameter("N_documento")!=null){ 
            s.setNumdoc( Integer.parseInt(req.getParameter("N_documento")));
        }
        if(req.getParameter("NombreUsuario")!=null){
            s.setNomusu(req.getParameter("NombreUsuario"));
        }
        if(req.getParameter("ContrasenaUsuario")!=null){
            s.setConntrausu(req.getParameter("ContrasenaUsuario"));
        }
        if(req.getParameter("NumeroCelularUsuario")!=null){
            s.setNumcelusu( Integer.parseInt(req.getParameter("NumeroCelularUsuario")));
        } 

        if(req.getParameter("chkestado")!=null){
            s.setEstadusu(true);
        }
        else{
            s.setEstadusu(false);
        }
        try { 
            System.out.println("id controlador "+s.getUsuario());
            s2.actualizar(s);
            System.out.println("actualizacion  insertado correctamente");
            
        } catch (Exception e) {
            System.out.println("Error en la inserción del registro "+e.getMessage().toString());
        }
    
      }



    private void listar(HttpServletRequest req, HttpServletResponse resp) {
        try {
            List usuario = s2.listar();
            req.setAttribute("usuarios",usuario);
            req.getRequestDispatcher("usuario.jsp").forward(req, resp); 
            System.out.println(usuario);
            System.out.println("Datos listados correctamente");
        } catch (Exception e) {
            System.out.println("Hay problemas al listar los datos "+e.getMessage().toString());
        }
    }}
